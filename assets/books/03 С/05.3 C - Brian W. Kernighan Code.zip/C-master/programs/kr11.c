#include <stdio.h>
main()
{
	printf("hello, world\n");

	printf("hello, ");
	printf("world");
	printf("\n");

	printf("a\tbb\b\"cc\"");
	printf("\n");
}
