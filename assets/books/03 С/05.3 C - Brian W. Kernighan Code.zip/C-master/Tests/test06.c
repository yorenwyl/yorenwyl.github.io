#include <stdio.h>
int main(){ perror("error message"); }
