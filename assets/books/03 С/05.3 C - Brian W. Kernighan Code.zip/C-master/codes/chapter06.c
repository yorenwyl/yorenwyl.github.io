
//chapter6: structures
//6.1 basics of structures
//6.2 structures and functions
//6.3 arrays of structures
//6.4 pointers to structures
//6.5 self-referencial structures
//6.6 table lookup
//6.7 typedef
//6.8 unions
//6.9 bit-fields

