

//chapter8: the unix system interface
//8.1 file descriptors
//8.2 low level I/O - read and write
//8.3 open, creat, close and unlink
//8.4 random access - lseek
//8.5 example - an implementation of fopen and getc
//8.6 example - listing directories
//8.7 example - a storage allocator

