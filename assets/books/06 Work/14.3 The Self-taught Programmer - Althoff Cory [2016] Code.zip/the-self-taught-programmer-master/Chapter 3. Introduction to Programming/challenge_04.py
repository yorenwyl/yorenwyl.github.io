# Create a program that divides two variables and prints the remainder
a = 5
b = 2

if a % b == 0:
    print("Your number is even!")
else:
    # Printing the remainder of 5 divided by 2 with the modulus operator, lit.
    print(a % b)
