# Create a program that takes two variables, divides them, and prints the quotient.

a = 13
b = 8

print(a // b)
