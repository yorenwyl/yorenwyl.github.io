# Print three different strings.

print("Code")
print("Like")
print("n00b")
