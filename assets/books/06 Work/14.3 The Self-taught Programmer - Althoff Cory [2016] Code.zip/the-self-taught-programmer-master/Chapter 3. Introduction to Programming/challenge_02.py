# Write a program that prints a message if a variable is less than 10
# and different message if the variable is greater than or equal to 10.

a = 5
if a < 10:
    print("Your variables assigned int value is less than ten playa.")
else:
    print("Your variable is greater than 10!")
