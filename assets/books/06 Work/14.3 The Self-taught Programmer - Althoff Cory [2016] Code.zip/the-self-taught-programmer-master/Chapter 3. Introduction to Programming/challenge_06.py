# Write a program with a variable age assigned to an integer that prints
# different strings depending on what integer age is.

age = 21

if age == 18:
    print("You're a young adult!")
elif age == 21:
    print("You're a young adult and can drink now!")
else:
    print("It's all downhill from here.")
