# Write a program that prints a message if a variable is less
# than or equal to 10, another message if the variable is greater
# than 10 but less than or equal to 25, and another message if the
# variable is greater than 25.

num = 26

if num <= 10:
    print("Your input is less than 10 yo.")
elif num <= 25:
    print("Your number is between 10 and 25 and or the numbers indicated in this string.")    
else:
    print("Your number is greater than 25.")
