# Write a function that takes a number as an input and returns that number squared
# Function takes on parameter and returns a value of int value 
# multiplied by itself.
def square(x):
  return x * x

print square(6)