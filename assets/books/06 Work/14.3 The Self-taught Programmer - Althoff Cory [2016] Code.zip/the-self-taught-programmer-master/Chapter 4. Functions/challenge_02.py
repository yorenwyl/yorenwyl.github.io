# Create a function that accepts a string as a parameter and prints it
# Pass in a string to the function and print it
def print_string(str):
  print(str)

print_string("sup")