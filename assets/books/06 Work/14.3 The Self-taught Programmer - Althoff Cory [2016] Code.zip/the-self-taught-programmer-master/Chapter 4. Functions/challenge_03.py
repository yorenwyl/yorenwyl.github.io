# Write a function that takes three required parameters and two optional parameters.
# Function with several parameter that will return added together
# 3 required params and 3 optional
def hella_params(x, y, z, s = 30, t = 10):
  return x + y + z + s + t

print hella_params(1, 1, 1, 1)