# Try to print something other than "Hello, World!"

print("Printing something other than Hello, World! lul")
