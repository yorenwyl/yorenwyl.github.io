# the-self-taught-programmer
The definitive guide to programming professionally by Cory Althoff
